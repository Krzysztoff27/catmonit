import { Grid } from '@mantine/core'
import React from 'react'

function ServiceStatusWidget() {
    return (
        <Grid>
            <Grid.Col span={4}>Service</Grid.Col>
        </Grid>
    )
}

export default ServiceStatusWidget