import { Box, Center, Flex, Group, Paper, Text } from "@mantine/core";
import { IconAlertTriangleFilled, IconExclamationCircleFilled, IconEyeOff, IconX } from "@tabler/icons-react";
import DeviceTitle from "../DeviceTitle/DeviceTitle";
import classes from "./AlertListElement.module.css";
import ScrollingText from "../ScrollingText/ScrollingText";

interface AlertListElementProps {
    isWarning: boolean;
    onRemove: () => void;
}

function AlertListElement({ isWarning, onRemove }: AlertListElementProps) {
    return (
        <Paper
            w="100%"
            bg="var(--background-color-6)"
            h="50px"
            style={{ overflow: "hidden" }}
        >
            <Group
                w="100%"
                h="100%"
                align="center"
                px="xs"
            >
                <DeviceTitle
                    name="Tuxaaaaaaaaaaaaaaaaaaaaaaaaaaa"
                    address="10.10.10.10"
                    iconSize={36}
                    style={{ overflow: "hidden" }}
                />
                <ScrollingText maw="50%">Storage below 5%. Free up space. Test Test Test Testaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa</ScrollingText>

                <Flex
                    justify="center"
                    w="fit-content"
                    pr="xs"
                    ml="auto"
                >
                    {/* might want to add  some pop-up when on hover
                    and change color of the icon */}
                    <IconEyeOff
                        stroke="2.5"
                        size={18}
                        color="var(--background-color-3)"
                        onClick={onRemove}
                        style={{ cursor: "pointer" }}
                    />
                </Flex>
            </Group>
        </Paper>
    );
}

export default AlertListElement;
