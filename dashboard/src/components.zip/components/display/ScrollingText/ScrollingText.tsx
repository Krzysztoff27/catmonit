import { Box, BoxComponentProps, PolymorphicComponentProps, Text } from "@mantine/core";
import classes from "./ScrollingText.module.css";

const ScrollingText = ({ children, ...props }): React.JSX.Element => {
    return (
        <Box
            className={classes.container}
            {...props}
        >
            {children}
        </Box>
    );
};

export default ScrollingText;
